import unittest
from ngslite.wobble_codon import pretty_print_wobble_codon_dict


class TestWobbleCodon(unittest.TestCase):

    def test_pretty_print_wobble_codon_dict(self):
        pretty_print_wobble_codon_dict()
