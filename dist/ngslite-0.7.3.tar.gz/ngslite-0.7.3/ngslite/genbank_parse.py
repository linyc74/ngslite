from .gtftools import GtfWriter
from .fasta import FastaWriter


class GbFeature(object):
    """
    A data class to store the information of an annotation of genbank file
    
    For example the text would look like:
    '     gene            complement(12..2189)
    '                     /gene="rIIA"
    '                     /locus_tag="T4p001"
    '                     /db_xref="GeneID:1258593"
    """
    def __init__(self, type_, start, end, strand, attributes=None):
        """
        Args:
            type_: str,
                Types defined in genbank file, for example 'gene', 'CDS', 'misc_feature'

            start: int,
                1-based, inclusive

            end: int,
                1-based, inclusive

            strand: str
                '+', '-'

            attributes: list of tuples of (key, value) pairs
                for example
                [
                    ('gene', 'rIIA'),
                    ('locus_tag', 'T4p001'),
                    ('db_xref', 'GeneID:1258593')
                ]
        """
        self.type = type_
        self.start = start
        self.end = end
        self.strand = strand
        if attributes is None:
            self.attributes = []
        else:
            self.attributes = attributes


def __get_genome_id(genome_text):
    """
    Args:
        genome_text: str
            The complete text block of a contig (or genome) in a genbank file,
                starting from 'LOCUS' and ending before '\n//'

    Returns: str,
        The contig_id (or accession number) in the very first line
    """
    line1 = genome_text.splitlines()[0]
    # After 'LOCUS' and before several space
    contig_id = line1[len('LOCUS'):].lstrip().split(' '*3)[0]
    return contig_id


def __get_LOCUS_section(genome_text):
    """
    Args:
        genome_text: str
            The complete text block of a contig (or genome) in a genbank file,
                starting from 'LOCUS' and ending before '\n//'

    Returns: str,
        The header section starting from 'LOCUS' ending before 'FEATURES'
            without trailing '\n'
    """
    return genome_text.split('\nFEATURES')[0]


def __get_FEATURES_section(genome_text):
    """
    Args:
        genome_text: str
            The complete text block of a contig (or genome) in a genbank file,
                starting from 'LOCUS' and ending before '\n//'

    Returns: str,
        The annotation section starting from 'FEATURES' ending before 'ORIGIN'
            without trailing '\n'
    """
    return 'FEATURES' + genome_text.split('\nFEATURES')[1].split('\nORIGIN')[0]


def __get_ORIGIN_section(genome_text):
    """
    Args:
        genome_text: str
            The complete text block of a contig (or genome) in a genbank file,
                starting from 'LOCUS' and ending before '\n//'

    Returns: str,
        The sequence section starting from 'ORIGIN' to the end
            without trailing '\n'
    """
    return 'ORIGIN' + genome_text.split('\nORIGIN')[1].rstrip()


def __split_feature_text(all_feature_text):
    """
    Split the complete feature text block into smaller blocks, in which
        each small block is a feature

    Args:
        all_feature_text: str
            for example

            'FEATURES             Location/Qualifiers
            '     source          1..168903
            '                     /organism="Enterobacteria phage T4"
            '                     /mol_type="genomic DNA"
            '                     /db_xref="taxon:10665"
            '     gene            complement(12..2189)
            '                     /gene="rIIA"
            '                     /locus_tag="T4p001"
            '                     /db_xref="GeneID:1258593"

    Returns: list of str
        for example [str1, str2], where

        str1 =
            '     source          1..168903
            '                     /organism="Enterobacteria phage T4"
            '                     /mol_type="genomic DNA"
            '                     /db_xref="taxon:10665"

        str2 =
            '     gene            complement(12..2189)
            '                     /gene="rIIA"
            '                     /locus_tag="T4p001"
            '                     /db_xref="GeneID:1258593"
    """
    L = []
    for line in all_feature_text.splitlines()[1:]:
        if line.strip() == '':  # empty line with only blank spaces
            continue
        if line.startswith(' '*21):
            L[-1] = L[-1] + line + '\n'
        else:
            L.append(line + '\n')

    return L


def __get_feature_type(feature_text):
    """
    Args:
        feature_text: str,
            for example

            '     CDS             complement(12..2189)
            '                     /gene="rIIA"
            '                     /locus_tag="T4p001"
            '                     /db_xref="GeneID:1258593"

    Returns: str
        The example would be 'CDS'
    """
    line1 = feature_text.splitlines()[0]
    return line1.strip().split()[0]


def __get_feature_location(feature_text):
    """
    Args:
        feature_text: str,
            for example

            '     CDS             complement(12..2189)
            '                     /gene="rIIA"
            '                     /locus_tag="T4p001"
            '                     /db_xref="GeneID:1258593"

    Returns:
        start: int
            The example would be 12

        end: int
            The example would be 2189

        strand: str, '+' or '-'
            The example would be '-'
    """
    line1 = feature_text.splitlines()[0]
    region = line1.strip().split()[1]

    if region.startswith('complement('):
        strand = '-'
        region = region[len('complement('):-1]
    else:
        strand = '+'

    start = int(region.split('..')[0])
    if '..' in region:
        end = int(region.split('..')[1])
    else:
        end = start

    return start, end, strand


def __get_feature_attributes(feature_text):
    """
    Args:
        feature_text: str,
            for example

            '     CDS             complement(12..2189)
            '                     /gene="rIIA"
            '                     /locus_tag="T4p001"
            '                     /db_xref="GeneID:1258593"

    Returns: list of tuples of (key, value) pairs
        The example would be
        [
            ('gene', 'rIIA'),
            ('locus_tag', 'T4p001'),
            ('db_xref', 'GeneID:1258593')
        ]
    """
    # Remove the first line
    feature_text = '\n'.join(feature_text.splitlines()[1:])

    # Parse as a list of str, each str is 'key="text"' or 'key=value'
    attr_list = list()
    for line in feature_text.splitlines():
        if line.startswith(' '*21+'/') and '=' in line:
            attr_list.append(line[22:])
        else:
            attr_list[-1] = attr_list[-1] + line.lstrip()

    # Unpack key="value" or key=value into a list of tuples (key, value)
    for i, attr in enumerate(attr_list):

        # With quote, value is text
        if '="' in attr:
            key, val = attr.split('="')
            val = val[:-1]

        # Without quote
        elif '=' in attr:
            key, val = attr.split('=')
            if val.isdigit():
                val = int(val)
        else:
            continue

        attr_list[i] = (key, val)

    return attr_list


def __inst_gb_feature(feature_text):
    """
    Parse a single feature text block, and then instantiate and return a GbFeature() object

    Args:
        feature_text: str
            For example

            '     gene            complement(12..2189)
            '                     /gene="rIIA"
            '                     /locus_tag="T4p001"
            '                     /db_xref="GeneID:1258593"

    Returns: GbFeature() object
    """
    # Introns (joined regions) are not supported
    if 'join(' in feature_text.split('\n')[0]:
        return None
    type_ = __get_feature_type(feature_text)
    start, end, strand = __get_feature_location(feature_text)
    attributes = __get_feature_attributes(feature_text)
    return GbFeature(type_, start, end, strand, attributes)


def __extract_features(all_feature_text):
    """
    Take the complete feature text block of one contig,
        parse the features into a list of GbFeature() objects

    Args:
        all_feature_text: str, for example

            'FEATURES             Location/Qualifiers
            '     source          1..168903
            '                     /organism="Enterobacteria phage T4"
            '                     /mol_type="genomic DNA"
            '                     /db_xref="taxon:10665"
            '     gene            complement(12..2189)
            '                     /gene="rIIA"
            '                     /locus_tag="T4p001"
            '                     /db_xref="GeneID:1258593"

    Returns: list of GbFeature() object
    """
    feature_arr = []

    for feature_text in __split_feature_text(all_feature_text):
        feature = __inst_gb_feature(feature_text)
        if feature is not None:
            feature_arr.append(feature)

    return feature_arr


def __filter_features(feature_arr, skip_types):
    """
    Args:
        feature_arr: list of GbFeature() object

        skip_types: str, or list of str
            Feature of types not to be included, for example 'source', 'CDS'

    Returns: list of GbFeature() object
    """
    return list(filter(lambda f: f.type not in skip_types, feature_arr))


def __pack_attributes(feature, skip_attributes):
    """
    Pack feature.attributes into a sinlge line of str,
        which is in the format of the GTF attribute field, for example:

        gene "AAA  [M=132]";accession "PF00004.29";...

    Args:
        feature: GbFeature() object

        skip_attributes: str, or list of str
            Attributes not to be included, for example ['translation', 'codon_start']

    Returns: str
    """
    if len(feature.attributes) == 0:
        return '.'
    s = ''
    for key, val in feature.attributes:
        if not key in skip_attributes:
            s += f"{key} \"{val}\";"
    return s[:-1]  # Remove trailing ";"


def extract_genbank_features_to_dict(file, skip_types):
    """
    Args:
        file: str, path-like
            The input genbank file

        skip_types: str, or list of str
            Feature of types not to be included
            For example, 'source' is skipped because it's just from the start to the end of genome

    Returns: dict()
        {
            contig_id_1: [GbFeature_1, GbFeature_2, ...],
            contig_id_2: [GbFeature_3, GbFeature_4, ...]
        }
    """
    D = dict()

    with open(file) as fh:
        for genome_text in fh.read().strip().split('\n//\n'):

            contig_id = __get_genome_id(genome_text)

            all_feature_text = __get_FEATURES_section(genome_text)

            # Extract <all_feature_text> -> a list of GbFeature() objects
            feature_arr = __extract_features(all_feature_text)
            feature_arr = __filter_features(feature_arr, skip_types)

            D[contig_id] = feature_arr

    return D


def genbank_to_gtf(file, output, skip_types='source', skip_attributes='translation'):
    """
    Extract features in the genbank file into GTF file

    Args:
        file: str, path-like
            The input genbank

        output: str, path-like
            The output GTF

        skip_types: str, or list of str
            Feature of types not to be included
            By default 'source' is skipped because it's just from the start to the end of genome

        skip_attributes: str, or list of str
            Attributes not to be included, for example ['translation', 'codon_start']
            By default skip "translation", i.e. the protein sequence
    """
    if type(skip_types) is str:
        skip_types = [skip_types]
    if type(skip_attributes) is str:
        skip_attributes = [skip_attributes]

    with GtfWriter(output) as writer:

        D = extract_genbank_features_to_dict(file, skip_types)

        for contig_id, feature_arr in D.items():

            for f in feature_arr:

                attr_str = __pack_attributes(f, skip_attributes)

                writer.write(
                    (contig_id,    # seqname
                     '.',          # source
                     f.type,       # feature type
                     f.start,      # start
                     f.end,        # end
                     '.',          # score
                     f.strand,     # strand
                     0,            # frame
                     attr_str)     # attribute
                )


def genbank_to_fasta(file, output):
    """
    Args:
        file: str, path-like
            The input genbank

        output: str, path-like
            The output fasta
    """
    with open(file) as fh:
        with FastaWriter(output) as writer:
            for genome_text in fh.read().strip().split('\n//\n'):
                contig_id = __get_genome_id(genome_text)
                seq_text = __get_ORIGIN_section(genome_text)
                seq = ''
                for line in seq_text.splitlines():
                    seq = seq + line[9:].replace(' ', '')
                writer.write(contig_id, seq)
