# ngslite
Light-weight functions for next-generation sequencing (NGS) data analysis
